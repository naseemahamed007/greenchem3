import React, { useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ArrowRight, Atom, BarChart3, Beaker, Check, CheckCircle2, ChevronRight, CircleHelp,
  FlaskConical, Gauge, Leaf, Menu, Pause, Play, Recycle, RotateCcw, ShieldCheck,
  Sparkles, Target, Trophy, X, Zap, Waves, Factory, Globe2, Droplets, Wind, Sun,
  Calculator, Microscope, Lightbulb, TimerReset
} from 'lucide-react'

const principles = [
['01','Prevent Waste','Preventing waste is better than treating or cleaning it up later.',Recycle],
['02','Atom Economy','Design reactions so that as much of the starting material as possible becomes the desired product.',Atom],
['03','Less Hazardous Synthesis','Use methods that generate little or no toxicity.',ShieldCheck],
['04','Safer Chemicals','Design products that work effectively while reducing harmful effects.',Leaf],
['05','Safer Solvents','Avoid auxiliary substances where possible, or choose safer alternatives.',FlaskConical],
['06','Energy Efficiency','Minimize energy requirements and prefer near-ambient conditions.',Zap],
['07','Renewable Feedstocks','Prefer renewable raw materials when technically practical.',Sun],
['08','Reduce Derivatives','Avoid unnecessary temporary modifications.',RotateCcw],
['09','Catalysis','Prefer catalytic reagents over stoichiometric reagents where possible.',Sparkles],
['10','Design for Degradation','Design products to break down into harmless substances after use.',Waves],
['11','Real-time Analysis','Monitor processes to prevent hazardous substances from forming.',BarChart3],
['12','Accident Prevention','Choose substances and conditions that reduce accident potential.',ShieldCheck]
]

const quiz = [
['What is the central idea of green chemistry?',['Prevent pollution at the source','Clean pollution after it forms','Use more chemicals','Increase waste'],0,'Green chemistry focuses on prevention by design.'],
['Which principle asks how much reactant becomes desired product?',['Energy efficiency','Atom economy','Accident prevention','Degradation'],1,'Atom economy rewards efficient incorporation of reactant atoms into the desired product.'],
['Which choice is generally greener?',['Unnecessary derivatives','Safer solvents','More toxic reagents','Single-use waste'],1,'Safer solvents can reduce hazards and environmental impact.'],
['Why are catalysts valuable?',['They can improve selectivity and efficiency','They always create more waste','They replace every reactant','They make all reactions instant'],0,'Catalysts can enable efficient reactions under milder conditions.'],
['What does design for degradation mean?',['Products should persist forever','Products should become harmless after use','Products should be harder to recycle','Products should be more toxic'],1,'The goal is useful products that can break down into benign substances after their useful life.']
]

const scenarios = [
 {id:'solvent',title:'Choose a solvent',icon:Droplets,options:[
  ['Conventional solvent','Higher hazard indicator','risk',35],['Safer solvent','Lower hazard indicator','green',85],['No solvent where practical','Excellent prevention option','best',100]]},
 {id:'energy',title:'Choose process conditions',icon:Zap,options:[
  ['High temperature / pressure','Higher energy demand','risk',30],['Moderate conditions','Reduced energy demand','green',75],['Near ambient conditions','Strong energy-efficiency choice','best',100]]},
 {id:'feedstock',title:'Choose feedstock',icon:Leaf,options:[
  ['Non-renewable raw material','Finite resource','risk',35],['Partly renewable input','Improved resource profile','green',75],['Renewable feedstock','Renewable resource choice','best',100]]}
]

function Icon({C,size=20}){return <C size={size} strokeWidth={1.8}/>}
function Button({children,onClick,secondary=false,small=false}){return <button className={`${secondary?'btn secondary':'btn'} ${small?'small':''}`} onClick={onClick}>{children}</button>}

function App(){
 const [page,setPage]=useState('home'); const [menu,setMenu]=useState(false); const [exhibit,setExhibit]=useState(false)
 const go=p=>{setPage(p);setMenu(false);window.scrollTo({top:0,behavior:'smooth'})}
 const nav=[['home','Home'],['explore','Explore'],['lab','Green Lab'],['tools','Smart Tools'],['quiz','Challenge']]
 return <div className="app">
  <Header page={page} go={go} menu={menu} setMenu={setMenu} nav={nav} onExhibit={()=>setExhibit(true)}/>
  <AnimatePresence mode="wait"><motion.div key={page} initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-8}} transition={{duration:.25}}>
   {page==='home'&&<Home go={go} onExhibit={()=>setExhibit(true)}/>} 
   {page==='explore'&&<Explore/>}
   {page==='lab'&&<GreenLab/>}
   {page==='tools'&&<Tools/>}
   {page==='quiz'&&<Quiz/>}
  </motion.div></AnimatePresence>
  <Footer go={go}/>
  {exhibit&&<ExhibitionMode close={()=>setExhibit(false)} go={go}/>} 
 </div>
}

function Header({page,go,menu,setMenu,nav,onExhibit}){return <header className="header">
 <button className="brand" onClick={()=>go('home')}><span className="brand-icon"><Leaf size={21}/></span><span>Green<span className="brand-accent">Chem</span></span></button>
 <nav className={`nav ${menu?'open':''}`}>{nav.map(([id,label])=><button key={id} className={page===id?'active':''} onClick={()=>go(id)}>{label}</button>)}</nav>
 <div className="header-actions"><button className="exhibit-btn" onClick={onExhibit}><Microscope size={17}/> Exhibition Mode</button><button className="menu" onClick={()=>setMenu(!menu)}>{menu?<X/>:<Menu/>}</button></div>
 </header>}

function Home({go,onExhibit}){return <main>
 <section className="hero">
  <div className="hero-grid"></div><div className="glow g1"></div><div className="glow g2"></div>
  <div className="hero-copy"><div className="eyebrow"><span className="live-dot"></span>INTERACTIVE CHEMISTRY • EXHIBITION 2026</div>
   <h1>Design chemistry<br/><span>for a greener planet.</span></h1>
   <p className="hero-lead">Discover how chemists can prevent waste, reduce hazards, save energy and build a more sustainable future — before pollution is created.</p>
   <div className="hero-buttons"><Button onClick={()=>go('lab')}>Enter Green Lab <ArrowRight/></Button><Button secondary onClick={()=>go('explore')}>Explore the 12 principles</Button></div>
   <div className="hero-proof"><div><b>12</b><span>principles</span></div><div><b>5</b><span>interactive tools</span></div><div><b>∞</b><span>greener ideas</span></div></div>
  </div>
  <MoleculeVisual/>
 </section>
 <section className="impact-strip"><Impact icon={Factory} value="Less waste" text="Prevent it at source"/><Impact icon={Zap} value="Less energy" text="Prefer efficient conditions"/><Impact icon={ShieldCheck} value="Less hazard" text="Safer by design"/><Impact icon={Globe2} value="More future" text="Think life cycle"/></section>
 <section className="section"><SectionHeading kicker="THE BIG IDEA" title={<>Don't just <span>clean up</span> pollution.</>} text="The most powerful solution is to design chemistry so pollution and waste are never created in the first place."/>
  <div className="idea-grid"><Idea number="01" icon={Recycle} title="Prevent" text="Avoid waste before it needs treatment."/><Idea number="02" icon={Zap} title="Optimize" text="Use less energy and fewer resources."/><Idea number="03" icon={ShieldCheck} title="Protect" text="Choose safer substances and processes."/><Idea number="04" icon={Globe2} title="Regenerate" text="Think about what happens after use."/></div>
 </section>
 <section className="spotlight"><div><span className="kicker light">LIVE DEMO</span><h2>Can you make a process greener?</h2><p>Change the process choices and watch the Green Score respond.</p><Button onClick={()=>go('lab')}>Try the simulator <ArrowRight/></Button></div><ScoreCard score={91}/></section>
 <section className="section final-cta"><div className="cta-card"><div><span className="kicker">FOR VISITORS & JUDGES</span><h2>One screen. A complete Green Chemistry story.</h2><p>Use Exhibition Mode for a clean, distraction-free walkthrough of the project.</p></div><Button secondary onClick={onExhibit}><Microscope/> Open Exhibition Mode</Button></div></section>
 </main>}

function MoleculeVisual(){return <div className="molecule-wrap"><div className="molecule-halo"></div><div className="molecule"><div className="core"><Atom size={68}/></div>{Array.from({length:6}).map((_,i)=><motion.div key={i} className="orbit" style={{'--i':i}} animate={{rotate:360}} transition={{duration:9+i*1.5,repeat:Infinity,ease:'linear'}}><i></i></motion.div>)}<div className="float f1">🌱</div><div className="float f2">♻</div><div className="float f3">⚗</div></div><div className="molecule-caption"><span className="signal"></span><span>CHEMISTRY × SUSTAINABILITY</span></div></div>}
function Impact({icon,value,text}){return <div className="impact"><span className="impact-icon"><Icon C={icon}/></span><div><b>{value}</b><span>{text}</span></div></div>}
function Idea({number,icon,title,text}){return <motion.div className="idea" whileHover={{y:-7}}><span className="idea-num">{number}</span><span className="idea-icon"><Icon C={icon}/></span><h3>{title}</h3><p>{text}</p></motion.div>}
function SectionHeading({kicker,title,text}){return <div className="section-heading"><div><span className="kicker">{kicker}</span><h2>{title}</h2></div><p>{text}</p></div>}

function Explore(){return <main className="page"><PageTitle kicker="EXPLORE" title={<>The 12 principles of <span>Green Chemistry.</span></>} text="Tap any principle to understand the design mindset behind safer, cleaner chemistry."/>
 <div className="principle-grid">{principles.map(([n,t,d,C],i)=><motion.article className="principle" key={n} initial={{opacity:0,y:18}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:.15}} transition={{delay:(i%4)*.05}} whileHover={{y:-6}}><div className="p-top"><span>{n}</span><span className="p-icon"><Icon C={C}/></span></div><h3>{t}</h3><p>{d}</p><div className="p-line"><i style={{width:`${55+(i%5)*8}%`}}></i></div></motion.article>)}</div>
 <section className="life-cycle"><div className="cycle-copy"><span className="kicker">THINK BEYOND THE REACTION</span><h2>Green chemistry follows the <span>whole life cycle.</span></h2><p>Raw materials → synthesis → product use → end of life. A green solution considers every stage, not just what happens inside the flask.</p></div><Cycle/></section>
 </main>}
function Cycle(){return <div className="cycle"><div className="cycle-ring"></div>{[['RAW',0],['MAKE',90],['USE',180],['RETURN',270]].map(([t,d])=><div className="cycle-node" key={t} style={{transform:`rotate(${d}deg) translateY(-118px) rotate(${-d}deg)`}}><span>{t}</span></div>)}<div className="cycle-center"><Globe2/><b>LOWER<br/>IMPACT</b></div></div>}

function GreenLab(){const [choices,setChoices]=useState({solvent:2,energy:2,feedstock:2}); const [show,setShow]=useState(false); const score=Math.round((scenarios.reduce((s,x)=>s+x.options[choices[x.id]][3],0))/3); const conventional=32; const saved=score-conventional; return <main className="page"><PageTitle kicker="GREEN LAB" title={<>Build a greener <span>process.</span></>} text="Make three design decisions. Your Green Score updates instantly."/>
 <div className="lab-layout"><div className="scenario-panel">{scenarios.map(s=><Scenario key={s.id} data={s} selected={choices[s.id]} setSelected={v=>setChoices(c=>({...c,[s.id]:v}))}/>)}</div><div className="score-panel"><div className="score-sticky"><span className="tag">LIVE GREEN SCORE</span><ScoreCard score={score}/><div className="score-change"><span>vs. conventional demo</span><b>+{saved} points</b></div><div className="score-bars"><Bar label="Resource efficiency" value={Math.min(100,score+3)}/><Bar label="Hazard reduction" value={Math.max(20,score-2)}/><Bar label="Energy efficiency" value={Math.min(100,score+1)}/></div><Button onClick={()=>setShow(!show)} secondary>{show?'Hide':'Explain'} my score <ChevronRight/></Button>{show&&<div className="score-note">This is an educational demonstration score, not a certified industrial sustainability assessment.</div>}</div></div></div>
 <div className="lab-footer"><Sparkles/><div><b>Best design mindset:</b> prevent waste, reduce hazard, use energy efficiently and choose better feedstocks.</div></div>
 </main>}
function Scenario({data,selected,setSelected}){const C=data.icon;return <section className="scenario"><div className="scenario-head"><span className="scenario-icon"><Icon C={C}/></span><div><span className="kicker">DESIGN DECISION</span><h3>{data.title}</h3></div></div><div className="option-grid">{data.options.map(([t,d,type,v],i)=><button key={t} className={`option ${selected===i?'selected':''} ${type}`} onClick={()=>setSelected(i)}><span className="option-radio">{selected===i?<Check/>:i+1}</span><div><b>{t}</b><small>{d}</small></div><strong>{v}</strong></button>)}</div></section>}
function Bar({label,value}){return <div className="bar-row"><div><span>{label}</span><b>{value}</b></div><div className="bar-track"><i style={{width:`${value}%`}}></i></div></div>}

function Tools(){const [raw,setRaw]=useState(100),[product,setProduct]=useState(85),[a,setA]=useState(70),[b,setB]=useState(20),[p,setP]=useState(70); const waste=Math.max(0,Number(raw)-Number(product)); const wastePct=Number(raw)?waste/Number(raw)*100:0; const atom=Math.min(100,Math.max(0,Number(p))); const score=Math.round(atom*.45+(100-wastePct)*.35+55*.2); return <main className="page"><PageTitle kicker="SMART TOOLS" title={<>Measure the <span>green difference.</span></>} text="Interactive calculators you can use while explaining the model to visitors."/>
 <div className="tools-grid">
 <Tool title="Waste Calculator" icon={Recycle} color="mint"><Field label="Starting material (g)" value={raw} set={setRaw}/><Field label="Product obtained (g)" value={product} set={setProduct}/><Result value={`${waste.toFixed(1)} g`} label={`${wastePct.toFixed(1)}% material not in product`} good={wastePct<20}/></Tool>
 <Tool title="Atom Economy Explorer" icon={Atom} color="cyan"><p className="tool-desc">Adjust the simplified reaction inputs and see the efficiency change.</p><div className="mass-row"><Field label="A (g/mol)" value={a} set={setA}/><Field label="B (g/mol)" value={b} set={setB}/></div><Field label="Desired product fraction (%)" value={p} set={setP}/><div className="atom-meter"><div style={{width:`${atom}%`}}></div></div><Result value={`${atom}%`} label="illustrative atom-economy indicator" good={atom>=80}/></Tool>
 <Tool title="Green Score Studio" icon={Gauge} color="violet"><div className="mini-score"><ScoreCard score={score}/></div><Bar label="Waste efficiency" value={Math.max(0,100-wastePct)}/><Bar label="Atom efficiency" value={atom}/><Bar label="Design quality" value={70}/><p className="disclaimer">Illustrative exhibition metric — use it to explain trends, not as a laboratory certification.</p></Tool>
 <Tool title="Quick Facts" icon={Lightbulb} color="gold"><Fact icon={Recycle} title="Prevention" text="Preventing waste is usually better than treating it later."/><Fact icon={Zap} title="Energy" text="Milder conditions can reduce energy demand."/><Fact icon={ShieldCheck} title="Safety" text="Hazard reduction starts with chemical design."/><Fact icon={Globe2} title="Life cycle" text="Think about materials before and after the reaction."/></Tool>
 </div></main>}
function Field({label,value,set}){return <label className="field"><span>{label}</span><input type="number" min="0" value={value} onChange={e=>set(e.target.value)}/></label>}
function Tool({title,icon,color,children}){return <section className={`tool color-${color}`}><div className="tool-head"><span><Icon C={icon}/></span><div><h3>{title}</h3><small>Interactive demonstration</small></div></div>{children}</section>}
function Result({value,label,good}){return <div className={`result ${good?'good':''}`}><b>{value}</b><span>{label}</span></div>}
function Fact({icon,title,text}){return <div className="fact"><Icon C={icon}/><div><b>{title}</b><p>{text}</p></div></div>}

function Quiz(){const [i,setI]=useState(0),[pick,setPick]=useState(null),[score,setScore]=useState(0),[done,setDone]=useState(false); const q=quiz[i]; const choose=x=>{if(pick!==null)return;setPick(x);if(x===q[2])setScore(s=>s+1)}; const next=()=>{if(i===quiz.length-1)setDone(true);else{setI(i+1);setPick(null)}}; const reset=()=>{setI(0);setPick(null);setScore(0);setDone(false)}; return <main className="page quiz-page"><PageTitle kicker="CHALLENGE" title={<>Test your <span>green thinking.</span></>} text="A short interactive challenge for exhibition visitors."/>{!done?<div className="quiz-box"><div className="quiz-top"><span>Question {i+1} / {quiz.length}</span><div><i style={{width:`${(i+1)/quiz.length*100}%`}}></i></div><b>{score} pts</b></div><div className="quiz-question"><span className="q-badge"><CircleHelp/></span><h2>{q[0]}</h2></div><div className="answers">{q[1].map((a,x)=><button key={a} className={pick===x?(x===q[2]?'right':'wrong'):(pick!==null&&x===q[2]?'right':'')} onClick={()=>choose(x)}><span>{String.fromCharCode(65+x)}</span>{a}{pick!==null&&x===q[2]&&<CheckCircle2/>}</button>)}</div>{pick!==null&&<motion.div className={`feedback ${pick===q[2]?'yes':'no'}`} initial={{opacity:0,y:8}} animate={{opacity:1,y:0}}><b>{pick===q[2]?'Correct!':'Not quite.'}</b><span>{q[3]}</span></motion.div>}{pick!==null&&<Button onClick={next}>{i===quiz.length-1?'See result':'Next question'} <ArrowRight/></Button>}</div>:<div className="quiz-result"><Trophy size={58}/><span className="kicker">YOUR RESULT</span><strong>{score}<small>/{quiz.length}</small></strong><h2>{score===5?'Outstanding green thinking!':score>=3?'Strong foundation!':'Great start — explore the principles and try again.'}</h2><p>Every correct answer is one more idea you can explain to a visitor.</p><Button onClick={reset}><RotateCcw/> Try again</Button></div>}</main>}

function ScoreCard({score}){const r=50,c=2*Math.PI*r,o=c-score/100*c;return <div className="score-card"><div className="ring"><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r={r}/><motion.circle cx="60" cy="60" r={r} strokeDasharray={c} initial={{strokeDashoffset:c}} animate={{strokeDashoffset:o}} transition={{duration:.8}}/></svg><div><strong>{score}</strong><span>/100</span></div></div><span>GREEN SCORE</span></div>}
function PageTitle({kicker,title,text}){return <div className="page-title"><span className="kicker">{kicker}</span><h1>{title}</h1><p>{text}</p></div>}

function ExhibitionMode({close,go}){const [slide,setSlide]=useState(0);const slides=[
 {tag:'01 • THE IDEA',title:'Chemistry can prevent pollution.',text:'Green chemistry changes the question from “How do we clean up waste?” to “How do we avoid creating it?”',icon:Leaf},
 {tag:'02 • THE FRAMEWORK',title:'12 principles guide better design.',text:'Waste prevention, atom economy, safer chemistry, energy efficiency, renewable feedstocks and more.',icon:Atom},
 {tag:'03 • THE INTERACTION',title:'Visitors make the decisions.',text:'Choose solvents, process conditions and feedstocks — then watch the Green Score respond.',icon:Gauge},
 {tag:'04 • THE TAKEAWAY',title:'Design for a cleaner future.',text:'The goal is chemistry that is effective, efficient, safer and more sustainable across its life cycle.',icon:Globe2}
];const s=slides[slide]; return <div className="exhibit-overlay"><button className="close-exhibit" onClick={close}><X/> Close</button><div className="exhibit-progress">{slides.map((_,i)=><i key={i} className={i===slide?'on':''}></i>)}</div><div className="exhibit-content"><motion.div key={slide} initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="exhibit-slide"><span className="kicker light">{s.tag}</span><div className="exhibit-icon"><Icon C={s.icon} size={62}/></div><h1>{s.title}</h1><p>{s.text}</p>{slide===2?<Button onClick={()=>{close();go('lab')}}>Open Green Lab <ArrowRight/></Button>:<Button onClick={()=>setSlide((slide+1)%slides.length)}>Continue <ArrowRight/></Button>}</motion.div></div><div className="exhibit-bottom"><button onClick={()=>setSlide(Math.max(0,slide-1))}>← Previous</button><span>GREENCHEM • EXHIBITION MODE</span><button onClick={()=>setSlide(Math.min(slides.length-1,slide+1))}>Next →</button></div></div>}

function Footer({go}){return <footer><div className="footer-brand"><span className="brand-icon"><Leaf size={19}/></span><b>GreenChem</b><p>Interactive Green Chemistry exhibition project.</p></div><div className="footer-links"><button onClick={()=>go('explore')}>12 Principles</button><button onClick={()=>go('lab')}>Green Lab</button><button onClick={()=>go('tools')}>Smart Tools</button><button onClick={()=>go('quiz')}>Challenge</button></div><div className="footer-credit">Designed & developed by <strong>Naseem Ahamed</strong></div></footer>}
export default App
