# GreenChem — Interactive Exhibition App

A premium React + Vite interactive Green Chemistry exhibition experience.

## Features
- Animated landing page and molecule visual
- 12 Green Chemistry principles
- Interactive Green Lab with live Green Score
- Waste Calculator
- Atom Economy Explorer
- Green Score Studio
- Quick Facts
- Visitor quiz / challenge
- Full-screen Exhibition Mode
- Responsive mobile/tablet/desktop design
- GitHub Pages / Vercel compatible Vite configuration
- Footer credit: Designed & developed by Naseem Ahamed

## Run locally
```bash
npm install
npm run dev
```

## Production test
```bash
npm run build
npm run preview
```

## Deploy to Vercel
1. Push the project contents to GitHub.
2. Import the repository at Vercel.
3. Framework: Vite.
4. Build command: `npm run build`.
5. Output directory: `dist`.

## Deploy to GitHub Pages
This project uses `base: './'`, so it is suitable for static GitHub Pages hosting. Build with `npm run build`, then publish the generated `dist` folder using your preferred GitHub Pages workflow.

## Important
All Green Score and environmental values are **illustrative educational values** for exhibition use. They are not industrial safety, LCA, or regulatory assessments.
